var monsters = require("./monsters");
// var bounty = require("./bounty");
// console.log(monsters.getMonsterStatsByWorld("Damons"));
monsters.getNames();
