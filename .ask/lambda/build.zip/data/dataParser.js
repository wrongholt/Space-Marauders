// /*jshint esversion: 8 */
// const fs = require("fs");
// var _ = require("lodash");
// // const helpers = require("../helpers/helpers");
// // Get document, or throw exception on error
// let doc = {};
// try {
//   doc = JSON.parse(fs.readFileSync(__dirname + "/factions.json", "utf8"));
// } catch (e) {
//   console.log(e);
// }
